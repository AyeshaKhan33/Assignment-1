#include <iostream>
using namespace std;

int main()
{
	int x;
	bool b;
	
	cout<<"Enter an integer: ";
	cin>>x;
	
	if(x>10 && x<=20)
	{
		b = true;
		cout<<b;
	}
	else
	{
		b = false;
		cout<<b;
	}
	return 0;
}


