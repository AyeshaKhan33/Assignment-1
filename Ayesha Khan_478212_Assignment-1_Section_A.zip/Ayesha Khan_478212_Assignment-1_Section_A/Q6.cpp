# include <iostream>
using namespace std;
int main(){
	int a, b, temp;
	
	cout<<"Enter the dividend: ";
	cin>>a;
	cout<<"Enter the divisor: ";
	cin>>b;
	
	if(a<b)
	{
		temp = a;
		a = b;
		b = temp;
	}
	int c =0, e = a;
	for(; e>=b ;c++)
	{
		e=e-b;	
	}
	
	cout<<a<<"/"<<b<<" is: "<<c<<endl;
	return 0;
}



