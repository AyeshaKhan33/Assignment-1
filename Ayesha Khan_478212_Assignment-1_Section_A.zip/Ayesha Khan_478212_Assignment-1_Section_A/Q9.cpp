#include <iostream>
using namespace std;

int main() 
{ 
    int n, X;
    cout<<"Enter value of integer X: ";
    cin>>X;
    
    cout<<"Enter the size of the array: ";
    cin>>n;
    int A[n];
    
    cout<<"Enter elements of the array: ";
    for(int i=0; i<n; i++)
    {
    	cin>>A[i];
	}
	bool TripletFound = false;
	 for (int i = 0; i < n - 2; i++) {
        for (int j = i + 1; j < n - 1; j++) {
            for (int k = j + 1; k < n; k++) {
                if (A[i] + A[j] + A[k] == X) {
                    cout << "Triplet found: " << A[i] << ", " << A[j] << ", " << A[k] <<endl;
                    TripletFound = true;
                }
            }
        }
    }

    if (!TripletFound) {
        cout << "No triplet found with sum equal to " << X << std::endl;
    }

    return 0;
}

