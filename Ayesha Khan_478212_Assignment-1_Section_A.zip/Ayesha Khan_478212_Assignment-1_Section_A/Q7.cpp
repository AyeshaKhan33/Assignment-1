#include<iostream>
using namespace std;
int main()
{
	int n;
	cout<<"Enter the size of your string: ";
	cin>>n;
	char array[n]={};
	cout<<"Enter the string : ";
	
	for(int i=0; i<n; i++)
	{
		cin>>array[i];
	}

int newsize=n;
	for(int i=0; i<n; i++)
	{
		for(int j=i+1; j<newsize; j++)
		{
			if(array[j]==array[i])
			{
			for(int k=j; k<newsize; k++)
			{
				array[k]=array[k+1];
			}
			newsize--;
			j--;
			}
		}
	}
	
	cout<<"The new string is : ";
	for(int i=0; i<newsize; i++)
	{
		cout<<array[i];
	}
	
return 0;
}
