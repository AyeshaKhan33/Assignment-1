# include <iostream>
using namespace std;
int main(){
	int c=5, n;
	int a[c]={1,2,3,4,5};
	cout<<"Enter new size of array: ";
	cin>>n;
	int b[n];
	for (int i=0;i<5;i++)
	{
		b[i]=a[i];
	}
	cout<<"Enter the "<<n-5<<" new elements: ";
	for(int i=5;i<n;i++) {
		cin>>b[i];
	}

	for (int i=0;i<8;i++)
	{
		cout<<b[i]<<" ";
	}
	return 0;
}

