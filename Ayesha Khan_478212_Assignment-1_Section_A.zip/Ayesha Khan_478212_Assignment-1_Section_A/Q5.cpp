#include <iostream>
#include <string>
using namespace std;
int main() {
  
    string s1, s2,s3;
    cout<<"Enter first string: ";
    cin >> s1;
    cout<<"Enter second string: ";
    cin >> s2;
    
    if (s1 == s2) { 
       int l= s1.length();
       s3=s1;
       
        int c=l;
        for (int i=0;i<l;i++)
        {
		
			s3[i]=s1[c-1];
			c--;
		}
	cout<< "After rotation: "<<endl;
	cout<<"String 1: "<< s3 << endl;
    cout<<"String 2: "<< s2 << endl;
    } 
	else {
        cout << "Not equal." << endl;
    }

    return 0;
}



